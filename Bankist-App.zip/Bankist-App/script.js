'use strict';

/////////////////////////////////////////////////
// BANKIST APP


const account1 = {
  owner: 'Jonas Schmedtmann',
  movements: [200, 455.23, -306.5, 25000, -642.21, -133.9, 79.97, 1300],
  interestRate: 1.2, // %
  pin: 1111,

  movementsDates: [
    '2019-11-18T21:31:17.178Z',
    '2019-12-23T07:42:02.383Z',
    '2025-01-28T09:15:04.904Z',
    '2025-04-01T10:17:24.185Z',
    '2025-02-19T14:11:59.604Z',
    '2025-02-20T17:01:17.194Z',
    '2025-02-20T23:36:17.929Z',
    '2025-02-19T10:51:36.790Z',
  ],
  currency: 'EUR',
  locale: 'pt-PT', // de-DEz
};

const account2 = {
  owner: 'Jessica Davis',
  movements: [5000, 3400, -150, -790, -3210, -1000, 8500, -30],
  interestRate: 1.5,
  pin: 2222,

  movementsDates: [
    '2019-11-01T13:15:33.035Z',
    '2019-11-30T09:48:16.867Z',
    '2019-12-25T06:04:23.907Z',
    '2025-01-25T14:18:46.235Z',
    '2025-02-05T16:33:06.386Z',
    '2025-02-20T19:43:26.374Z',
    '2025-02-19T18:49:59.371Z',
    '2025-02-18T12:01:20.894Z',
  ],
  currency: 'USD',
  locale: 'en-US',
};

const accounts = [account1, account2];

/////////////////////////////////////////////////
// Elements
const labelWelcome = document.querySelector('.welcome');
const labelDate = document.querySelector('.date');
const labelBalance = document.querySelector('.balance__value');
const labelSumIn = document.querySelector('.summary__value--in');
const labelSumOut = document.querySelector('.summary__value--out');
const labelSumInterest = document.querySelector('.summary__value--interest');
const labelTimer = document.querySelector('.timer');

const containerApp = document.querySelector('.app');
const containerMovements = document.querySelector('.movements');

const btnLogin = document.querySelector('.login__btn');
const btnTransfer = document.querySelector('.form__btn--transfer');
const btnLoan = document.querySelector('.form__btn--loan');
const btnClose = document.querySelector('.form__btn--close');
const btnSort = document.querySelector('.btn--sort');

const inputLoginUsername = document.querySelector('.login__input--user');
const inputLoginPin = document.querySelector('.login__input--pin');
const inputTransferTo = document.querySelector('.form__input--to');
const inputTransferAmount = document.querySelector('.form__input--amount');
const inputLoanAmount = document.querySelector('.form__input--loan-amount');
const inputCloseUsername = document.querySelector('.form__input--user');
const inputClosePin = document.querySelector('.form__input--pin');

/////////////////////////////////////////////////
// Functions


function createUsername(users){
  return users.map((curr, i) => curr.username = curr.owner.split(' ')[0]);
}
createUsername(accounts);

function calcPassedDays(date1, date2){
  return Math.round( Math.abs(date2 - date1) / (1000 * 60 * 60 * 24));
}

function formatCurrency(value, locale, currency){
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
  }).format(value);
}

function displayMoves(acc){
  containerMovements.innerHTML = '';
  acc.movements.forEach((mov, i) => {

    const date = new Date(acc.movementsDates[i]);
    let passedDays = calcPassedDays(new Date(), date);
    
    const hour = `${date.getHours()}`.padStart(2, 0);
    const minute = `${date.getMinutes()}`.padStart(2, 0);
    let displayDate;

    if(passedDays === 0 ){
       displayDate = `Today at ${hour}:${minute}`;
      }
    else if(passedDays === 1 ){
       displayDate = `Yesterday`;
      }
    else if(passedDays <= 7 ){
       displayDate = `${passedDays} days ago`;
      }
     else {
      displayDate = new Intl.DateTimeFormat('en-GB').format(date);
    }

    const formattedMov = formatCurrency(mov, acc.locale, acc.currency);
    const type = mov > 0 ? 'deposit': 'withdrawal'
    const html = `<div class="movements__row">
    <div class="movements__type movements__type--${type}">${++i} ${type}</div>
    <div class="movements__date">${displayDate}</div>
    <div class="movements__value">${formattedMov}</div>
  </div>`;

  containerMovements.insertAdjacentHTML('afterbegin', html);

}

)};

let timer;

function logoutTimeout(){
  
  function timing(){
    const min = String(time / 60).padStart(3, 0);
    const secs = String(time % 60).padStart(2, 0);

    labelTimer.textContent = `${Math.trunc(min)}:${secs}`;
    
    if(time === 0){
      clearInterval(timer);
      containerApp.style.opacity = 0;
      labelWelcome.textContent = `Log in To Get Started`;
    }  
    time--;
  }

  let time = 70;
  timing();

   timer = setInterval(timing, 1000);
}

function displaySummary(move){

  const inBalance = move.filter(mov => mov > 0).reduce((acc, curr) => acc + curr, 0);
  labelSumIn.textContent = formatCurrency(Math.abs(inBalance), currentUser.locale, currentUser.currency);

  const outBalance = move.filter(mov => mov < 0).reduce((acc, curr) => acc + curr, 0);
  labelSumOut.textContent = formatCurrency(Math.abs(outBalance), currentUser.locale, currentUser.currency);

  const interest = move.filter(mov => mov > 0).map(curr => curr * 1.2 /100).filter(int => int >0).reduce((acc, int) => acc + int, 0);
  labelSumInterest.textContent = formatCurrency(interest, currentUser.locale, currentUser.currency)

  const balance = currentUser?.movements.reduce((acc, curr) => acc + curr, 0);
  currentUser.balance = balance;
  labelBalance.textContent = formatCurrency(balance, currentUser.locale, currentUser.currency);

} 

  let currentUser;

  btnLogin.addEventListener('click', function(e){

    e.preventDefault();
    currentUser = accounts.find(acc => acc.username === inputLoginUsername.value)
    
  if(Number(inputLoginPin.value) === currentUser?.pin){
    containerApp.style.opacity = 1;
    inputCloseUsername.value = inputClosePin.value = '';
    inputLoginPin.value = '';
    inputLoginPin.blur();
    inputLoginUsername.value = '';

    labelWelcome.textContent = `Welcome Back ${currentUser.owner.split(' ')[0]}`

    displayMoves(currentUser);

    if(timer){
      clearInterval(timer);
    }
    logoutTimeout();
    displaySummary(currentUser.movements);
    const now = new Date();

    const locale = navigator.language;
    const options = {
      month: 'long',
      year: 'numeric',
      weekday: 'long',
    }
    labelDate.textContent = new Intl.DateTimeFormat(locale, options).format(now);
        
  }
  
})

  btnTransfer.addEventListener('click', function(e){
    
    const receiver = accounts.find(curr => curr.username === inputTransferTo.value);
    const amount = Number(inputTransferAmount.value);
    e.preventDefault();

    if(receiver && receiver.username !== currentUser?.username && currentUser?.balance >= amount && amount > 0){
      clearInterval(timer);
      logoutTimeout();        
      setTimeout(function(){
        receiver.movements.push(amount);
        currentUser.movements.push(-amount);
        currentUser.movementsDates.push(new Date().toISOString());
        receiver.movementsDates.push(new Date().toISOString());
        displayMoves(currentUser);
        displaySummary(currentUser.movements);

      }, 2000)

      inputTransferAmount.value = inputTransferTo.value = ''
      inputTransferAmount.blur()
    } 
  });

  btnLoan.addEventListener('click', function(e){
    e.preventDefault();
    
    
    const amount = Number(inputLoanAmount.value);
    const isEligible = currentUser.movements.filter(mov => mov > 0).find(mov => mov >= 0.1 * amount);
    
    if(isEligible && amount > 0){
      clearInterval(timer);
      logoutTimeout();

      setTimeout(function(){
        currentUser.movements.push(amount);
        currentUser.movementsDates.push(new Date().toISOString());
        displayMoves(currentUser);
        displaySummary(currentUser.movements);
      }, 5000)
      inputLoanAmount.value = ''
      
    } 
  });

  btnClose.addEventListener('click', function(e){
    e.preventDefault();

    if(currentUser?.username === inputCloseUsername.value && currentUser.pin === Number(inputClosePin.value)){
      const index = accounts.findIndex(curr => curr.username === inputCloseUsername.value);
      containerApp.style.opacity = 0;
      labelWelcome.textContent = `Log in To Get Started`;
      accounts.splice(index, 1);
      inputCloseUsername.value = inputClosePin.value = '';  
    }
  })





